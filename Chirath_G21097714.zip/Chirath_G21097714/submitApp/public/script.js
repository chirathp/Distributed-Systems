async function loadCategories() {
    try {
      const response = await fetch("http://localhost:4000/categories");
      const categories = await response.json();
  
      let options = "";
      categories.forEach(cat => {
        options += `<option value="${cat.name}">${cat.name}</option>`;
      });
  
      document.getElementById("categorySelect").innerHTML = options;
    } catch (error) {
      console.error("Failed to load categories:", error);
    }
  }
  
  async function submitQuestion() {
    const question = document.getElementById("questionInput").value;
    const answers = [
      document.getElementById("answer1").value,
      document.getElementById("answer2").value,
      document.getElementById("answer3").value,
      document.getElementById("answer4").value
    ];
    const correctAnswerIndex = document.getElementById("correctAnswer").value;
    const correctAnswer = document.getElementById(correctAnswerIndex).value;
    let category = document.getElementById("categorySelect").value;
    const newCategory = document.getElementById("newCategory").value;
  
    if (newCategory.trim() !== "") {
      category = newCategory;
    }
  
    if (!question || answers.some(a => a.trim() === "") || !correctAnswer || !category) {
      document.getElementById("statusMessage").innerText = "Please fill all fields!";
      return;
    }
  
    const requestBody = { question, answers, correctAnswer, category };
    
    const response = await fetch("http://localhost:4200/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody)
    });
  
    const data = await response.json();
    document.getElementById("statusMessage").innerText = data.message;
  }
  
  // Load categories when the page loads
  window.onload = loadCategories;
  