const express = require("express");
const cors = require("cors");
const path = require("path");
const db = require("./db");
require("dotenv").config();

// Swagger dependencies
const swaggerJsdoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");

const app = express();
app.use(cors());
app.use(express.json());

// Serve static files from the Submit folder
app.use(express.static(path.join(__dirname, "public")));

const swaggerOptions = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Quiz Submission API",
      version: "1.0.0",
      description: "API for submitting quiz questions and answers to the distributed quiz system",
      contact: {
        name: "Your Name",
        email: "your.email@example.com",
        url: "https://your-portfolio.com"
      },
      license: {
        name: "MIT",
        url: "https://opensource.org/licenses/MIT"
      }
    },
    servers: [
      {
        url: "http://localhost:4200",
        description: "Local development server"
      },
      {
        url: "https://20.39.226.184:4200",
        description: "Production server (Azure VM)"
      }
    ],
    tags: [
      {
        name: "Categories",
        description: "Operations related to question categories"
      },
      {
        name: "Questions",
        description: "Operations for submitting new questions"
      }
    ],
    components: {
      schemas: {
        QuestionSubmission: {
          type: "object",
          required: ["question", "answers", "correctAnswer", "category"],
          properties: {
            question: {
              type: "string",
              example: "What is the capital of France?",
              description: "The question text"
            },
            answers: {
              type: "array",
              minItems: 4,
              maxItems: 4,
              items: {
                type: "string"
              },
              example: ["London", "Paris", "Berlin", "Madrid"],
              description: "Array of 4 possible answers"
            },
            correctAnswer: {
              type: "string",
              example: "Paris",
              description: "The correct answer (must match one of the answers)"
            },
            category: {
              type: "string",
              example: "Geography",
              description: "Question category"
            }
          }
        },
        Category: {
          type: "object",
          properties: {
            name: {
              type: "string",
              example: "Science"
            }
          }
        },
        Error: {
          type: "object",
          properties: {
            error: {
              type: "string",
              example: "Database error"
            }
          }
        }
      }
    }
  },
  apis: ["./submitApp.js"],
};



const swaggerSpec = swaggerJsdoc(swaggerOptions);

// Serve Swagger UI
app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));



// Serve the submit.html file for the root route
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.get("/categories", async (req, res) => {
  try {
    const [categories] = await db.promise().query("SELECT DISTINCT name FROM categories");
    res.json(categories);
  } catch (err) {
    console.error("Error fetching categories:", err);
    res.status(500).json({ error: "Database error in fetching categories" });
  }
});



app.post("/submit", async (req, res) => {
  const { question, answers, correctAnswer, category } = req.body;

  // Validate input
  if (!question || !answers || !correctAnswer || !category) {
    return res.status(400).json({ error: "All fields are required" });
  }

  try {
    // Insert category if it doesn't exist
    await db.promise().query("INSERT IGNORE INTO categories (name) VALUES (?)", [category]);

    // Insert question
    const [questionResult] = await db.promise().query(
      "INSERT INTO questions (question, category, correctAnswer) VALUES (?, ?, ?)",
      [question, category, correctAnswer]
    );

    const questionId = questionResult.insertId;

    // Insert answers
    const answerQueries = answers.map(answer => 
      db.promise().query("INSERT IGNORE INTO answers (question_id, name) VALUES (?, ?)", [questionId, answer])
    );

    await Promise.all(answerQueries);

    res.json({ message: "Question submitted successfully" });
  } catch (err) {
    console.error("Error submitting question:", err);
    res.status(500).json({ error: "Database error in question submission" });
  }
});

// Run the server
const PORT = process.env.PORT || 3200;
app.listen(PORT, () => {
  console.log(`Submit Service running on port ${PORT}`);
  console.log(`API documentation available at http://localhost:${PORT}/docs`);
});

module.exports = app;