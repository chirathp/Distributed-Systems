
-- Table 1: Creating the first table
CREATE TABLE answers (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    question_id INT DEFAULT NULL
);

-- Table 2: Creating the second table
CREATE TABLE categories (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE
);

-- Table 3: Creating the third table
CREATE TABLE questions (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(255) UNIQUE,
    category VARCHAR(255) DEFAULT NULL,
    correctAnswer VARCHAR(255) DEFAULT NULL
);