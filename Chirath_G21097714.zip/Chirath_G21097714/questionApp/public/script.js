async function loadCategories() {
  try {
    const response = await fetch("http://localhost:4000/categories");
    const categories = await response.json();
    
    const select = document.getElementById("categorySelect");
    select.innerHTML = categories.map(cat => 
      `<option value="${cat.name}">${cat.name}</option>`
    ).join("");
  } catch (error) {
    console.error("Failed to load categories:", error);
    document.getElementById("statusMessage").textContent = 
      "Failed to load categories. Please try again later.";
  }
}

async function getQuestion() {
  const category = document.getElementById("categorySelect").value;
  if (!category) {
    document.getElementById("statusMessage").textContent = 
      "Please select a category first";
    return;
  }

  try {
    document.getElementById("statusMessage").textContent = "Loading question...";
    
    const response = await fetch(`http://localhost:4000/question/${category}`);
    const data = await response.json();

    if (data.length === 0) {
      document.getElementById("questionText").textContent = 
        "No questions available for this category!";
      document.getElementById("answers").innerHTML = "";
      document.getElementById("statusMessage").textContent = "";
      return;
    }

    const question = data[0];
    document.getElementById("questionText").textContent = question.question;
    document.getElementById("statusMessage").textContent = "";

    // Fetch answers
    const answersResponse = await fetch(
      `http://localhost:4000/answers/${question.id}`
    );
    const answersData = await answersResponse.json();

    if (answersData.length === 0) {
      document.getElementById("answers").innerHTML = 
        "No answers available for this question!";
      return;
    }

    // Shuffle answers
    const shuffledAnswers = [...answersData].sort(() => Math.random() - 0.5);
    
    // Display answers
    document.getElementById("answers").innerHTML = shuffledAnswers
      .map(answer => `
        <div class="answer-btn" onclick="checkAnswer(this, '${answer.name}', '${question.correctAnswer}')">
          ${answer.name}
        </div>
      `)
      .join("");
  } catch (error) {
    console.error("Error fetching question:", error);
    document.getElementById("statusMessage").textContent = 
      "Error loading question. Please try again.";
  }
}

function checkAnswer(button, selectedAnswer, correctAnswer) {
  // Disable all answer buttons
  document.querySelectorAll(".answer-btn").forEach(btn => {
    btn.style.pointerEvents = "none";
  });

  // Mark selected answer
  if (selectedAnswer === correctAnswer) {
    button.classList.add("correct");
  } else {
    button.classList.add("incorrect");
    
    // Highlight correct answer
    const correctButton = [...document.querySelectorAll(".answer-btn")].find(
      btn => btn.textContent.trim() === correctAnswer
    );
    if (correctButton) correctButton.classList.add("correct");
  }
}

// Load categories when page loads
window.onload = loadCategories;