const express = require("express");
const cors = require("cors");
const path = require("path"); // Import the path module
const db = require("./db"); // Import the common db.js
require("dotenv").config({ path: __dirname + "/../.env" }); // Load env

const fs = require('fs');
const app = express();
app.use(cors());
app.use(express.json());

// Serve static files from the Questions folder
app.use(express.static(path.join(__dirname, "public")));

// Serve the questions.html file for the root route
app.get("/", (req, res) => {
res.sendFile(path.join(__dirname, "public", "questions.html"));
});




app.get("/question/:category", (req, res) => {
const category = req.params.category;
const count = req.query.count || 1; // Default to 1 if no count is provided
const sql = "SELECT * FROM questions WHERE category = ? ORDER BY RAND() LIMIT ?";
db.query(sql, [category, count], (err, result) => {
    if (err) {
    console.error("Error fetching questions:", err);
    res.status(500).json({ error: "Database error in question selection" });
    } else {
    res.json(result);
    }
});
});




app.get("/categories", (req, res) => {
const sql = "SELECT DISTINCT name FROM categories";

db.query(sql, (err, result) => {
    if (err) {
    console.error("Error fetching categories:", err);
    res.status(500).json({ error: "Database error in selecting category" });
    } else {
    // Write to JSON file
    const filePath = path.join(__dirname, "cache", "Categories.json");
    fs.mkdirSync(path.dirname(filePath), { recursive: true });

    fs.writeFile(filePath, JSON.stringify(result, null, 2), "utf8", (writeErr) => {
        if (writeErr) {
        console.error("Error writing Categories.json:", writeErr);
        } else {
        console.log("Categories saved to Categories.json in cache folder.");
        }
    });

    res.json(result);
    }
});
});




app.get("/answers/:question_id", (req, res) => {
const id = req.params.question_id;  // Get the question_id from the request parameters
const sql = "SELECT DISTINCT name FROM answers WHERE question_id = ?";  // Use a placeholder for the parameter
db.query(sql, [id], (err, result) => {  // Pass the id as an array to parameterize the query
if (err) {
console.error("Error fetching answers:", err);
res.status(500).json({ error: "Database error in selecting answers" });
} else {
res.json(result);  // Send the result as the response
}
});
});


// Run the server on port 3000
const PORT = 3000;
app.listen(PORT, () => console.log(` Question Service running on port ${PORT}`));